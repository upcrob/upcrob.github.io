package com.upcrob.example.jotp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Simple servlet implementation class that demonstrates how a web application
 * can use jOTP to handle 2-factor authentication.  Normally, a framework would
 * be used to generate the page, handle the web service calls, etc.  However, I've
 * packaged the entire application into this single servlet for simplicity and to
 * show that jOTP can be used independently of web development frameworks.
 */
@WebServlet("/Controller")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	// jOTP Constants for this application
	private static final String JOTP_SERVER_ROOT = "http://localhost:8080/jOTP";
	private static final String JOTP_CLIENT_USERNAME = "mygroup";
	private static final String JOTP_CLIENT_PASSWORD = "mypass";
	
	// Constants for the test user
	// Normally, this information would be stored in a database
	private static final String TEST_USER_NAME = "testuser";
	private static final String TEST_USER_PASSWORD = "testpassword";
	private static final String TEST_USER_PHONE_NUMBER = "<PHONE NUMBER>";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String page = request.getParameter("page");
		if (page == null) {
			// No page requested, show welcome page
			writeWelcomePage(out, false);
		} else if (page.equals("login")) {
			writeLoginPage(out, request.getParameter("username"));
		} else if (page.equals("secured")) {
			// Try to show the 'secured' page
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String token = request.getParameter("token");
			if (username != null || password != null || token != null) {
				if (authenticate(username, password, token)) {
					// Authentication succeeded, show secure page
					writeSecurePage(out);
				} else {
					// Login failed, show welcome page with an error
					writeWelcomePage(out, true);
				}
			} else {
				// Login was not attempted, show plain welcome page
				writeWelcomePage(out, false);
			}
		} else {
			// Show welcome page by default
			writeWelcomePage(out, false);
		}
		
		out.close();
	}

	/**
	 * Write a simple welcome page with the username form.
	 * @param out The writer to write to.
	 * @param previousFailure Whether or not an error message should be shown with the form.
	 */
	private void writeWelcomePage(PrintWriter out, boolean previousFailure) {
		// Print initial content
		out.write("<html><head><title>Welcome</title></head><body>");
		out.write("<h1>Welcome to the jOTP test app</h1>");
		out.write("<p>Enter your username to get a one-time use token.</p>");
		
		// Write the username form
		out.write("<form method=\"post\" action=\"Controller\">");
		if (previousFailure) {
			out.write("<div style=\"color: red\">Login failed.</div>");
		}
		out.write("Username: <input type=\"text\" name=\"username\" /><br />");
		out.write("<input type=\"hidden\" name=\"page\" value=\"login\" />");
		out.write("<input type=\"submit\" value=\"Generate Token\" />");
		out.write("</form>");
		
		// End page
		out.write("</body></html>");
	}
	
	/**
	 * Write a login page.
	 * @param out The writer to write to.
	 * @param username The username to populate the username field with.  Blank if null.
	 */
	private void writeLoginPage(PrintWriter out, String username) {
		// Generate token for user
		generateToken(username);
		
		// Print initial content
		out.write("<html><head><title>Welcome</title></head><body>");
		out.write("<h1>Login</h1>");
		
		// Write the username form
		// I've left 'password' and 'token' as text fields for instructional
		// purposes.  These would normally be of the 'password' type to mask
		// the user's input.
		if (username == null)
			username = "";	// Default username to the empty string
		out.write("<form method=\"post\" action=\"Controller\">");
		out.write("Username: <input type=\"text\" name=\"username\" value=\"" + username + "\" /><br />");
		out.write("Password: <input type=\"text\" name=\"password\" /><br />");
		out.write("Auth Token: <input type=\"text\" name=\"token\" /><br />");
		out.write("<input type=\"hidden\" name=\"page\" value=\"secured\" />");
		out.write("<input type=\"submit\" value=\"Login\" />");
		out.write("</form>");
		
		// End page
		out.write("</body></html>");
	}
	
	/**
	 * Writes the 'secured' page content.
	 */
	private void writeSecurePage(PrintWriter out) {
		// Print 'secured' content
		out.write("<html><head><title>Welcome</title></head><body>");
		out.write("<h1>Secure Page</h1>");
		out.write("<p>You are viewing secured content!  That is to say, it required authentication...</p>");
		out.write("</body></html>");
	}
	
	/**
	 * Makes a RESTful call to jOTP to generate a token for the given username.
	 * Note that we do an internal lookup to correlate a username with a phone
	 * number.  In a 'real' application, this information would be stored in
	 * a database or directory.
	 * @param username Username to generate token for.
	 */
	private void generateToken(String username) {
		if (username != null && username.equals(TEST_USER_NAME)) {
			String endpoint = JOTP_SERVER_ROOT + "/otp/text";
			String params = "?client="
					+ JOTP_CLIENT_USERNAME
					+ "&clientpassword="
					+ JOTP_CLIENT_PASSWORD
					+ "&number="
					+ TEST_USER_PHONE_NUMBER;
			httpPost(endpoint + params);
		}
	}
	
	/**
	 * Makes a RESTful call to jOTP to determine if the token associated with
	 * a username is valid.  Again, we do an internal lookup to correlate the
	 * username with a phone number.
	 * @param username Username to check token against.
	 * @param token Token string to validate.
	 * @return Whether or not the token is valid.
	 */
	private boolean isTokenValid(String username, String token) {
		if (username != null && username.equals(TEST_USER_NAME)) {
			String endpoint = JOTP_SERVER_ROOT + "/otp/validate";
			String uid = TEST_USER_PHONE_NUMBER;
			String params = "?client="
					+ JOTP_CLIENT_USERNAME
					+ "&clientpassword="
					+ JOTP_CLIENT_PASSWORD
					+ "&uid="
					+ uid
					+ "&token="
					+ token;
			String response = httpPost(endpoint + params);
			
			// Normally we would parse the JSON response
			// Since this is a conceptual test app, we'll do a string
			// compare for simplicity and laziness...
			if (response != null && "{\"error\":\"\", \"tokenValid\":\"true\"}".equals(response.trim())) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}
	
	/**
	 * Authenticates a user.  This method first verifies that the username/password credentials
	 * are valid, and then verifies that the token matches one generated previously.  Both of
	 * these conditions must be met to successfully authenticate.
	 * @param username Username to authenticate.
	 * @param password User's password.
	 * @param token User's OTP token from jOTP.
	 * @return Whether or not the user could be authenticated successfully.
	 */
	private boolean authenticate(String username, String password, String token) {
		// Make sure all fields are non-null
		if (username == null || password == null || token == null)
			return false;
		
		// Check username / password pair
		if (!(username.equals(TEST_USER_NAME) && password.equals(TEST_USER_PASSWORD))) {
			return false;
		}
		
		// Check token
		if (!isTokenValid(username, token)) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * Simple method to POST to jOTP services.  Note that normally you would
	 * use a client library (like Apache HttpClient or Spring's RestTemplate) to
	 * take care of this.
	 */
	private String httpPost(String url) {
		BufferedReader in = null;
		StringBuilder sb = new StringBuilder();
		try {
			URL urlObj = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
			
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
			
			in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = in.readLine()) != null) {
				sb.append(line);
				sb.append("\n");
			}
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				if (in != null)
					in.close();
			} catch (IOException e) {
				// ignore
			}
		}
		
		return sb.toString();
	}
}
